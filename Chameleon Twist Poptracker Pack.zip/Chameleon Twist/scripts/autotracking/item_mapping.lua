-- use this file to map the AP item ids to your items
-- first value is the code of the target item and the second is the item type override (feel free to expand the table with any other values you might need (i.e. special inital values, increments, etc.)!)
-- here are the SM items as an example: https://github.com/Cyb3RGER/sm_ap_tracker/blob/main/scripts/autotracking/item_mapping.lua

ITEM_MAPPING = {

    ------    Toggles   ------

    [1]  = {{"shoot", "toggle"}},
    [2]  = {{"spin", "toggle"}},
    [3]  = {{"vault", "toggle"}},
    [4]  = {{"tongue", "toggle"}},
    [5]  = {{"jump", "toggle"}},
    [6]  = {{"enable_shrink", "toggle"}},
    [7]  = {{"enable_big", "toggle"}},
    [8]  = {{"enable_stop", "toggle"}},
    [9]  = {{"jl", "toggle"}},
    [10] = {{"al", "toggle"}},
    [11] = {{"bl", "toggle"}},
    [12] = {{"dc", "toggle"}},
    [13] = {{"kl", "toggle"}},
    [14] = {{"gc", "toggle"}},
    [15] = {{"q", "toggle"}},


    ------    Consumables    ------

    [16] = {{"crown_jl", "consumable"}, {"crown_total", "consumable"}},
    [17] = {{"crown_al", "consumable"}, {"crown_total", "consumable"}},
    [18] = {{"crown_bl", "consumable"}, {"crown_total", "consumable"}},
    [19] = {{"crown_dc", "consumable"}, {"crown_total", "consumable"}},
    [20] = {{"crown_kl", "consumable"}, {"crown_total", "consumable"}},
    [21] = {{"crown_gc", "consumable"}, {"crown_total", "consumable"}},
    [22] = {{"carrot_jl", "toggle"} ,{"carrot", "consumable"}},
    [23] = {{"carrot_al", "toggle"} ,{"carrot", "consumable"}},
    [24] = {{"carrot_bl", "toggle"} ,{"carrot", "consumable"}},
    [25] = {{"carrot_dc", "toggle"} ,{"carrot", "consumable"}},
    [26] = {{"carrot_kl", "toggle"} ,{"carrot", "consumable"}},
    [27] = {{"heart_p_jl", "consumable"}, {"heart_p_total", "consumable"}},
    [28] = {{"heart_o_jl", "consumable"}, {"heart_o_total", "consumable"}},
    [29] = {{"heart_y_jl", "toggle"}, {"heart_y_total", "consumable"}},
    [30] = {{"heart_p_al", "consumable"}, {"heart_p_total", "consumable"}},
    [31] = {{"heart_o_al", "consumable"}, {"heart_o_total", "consumable"}},
    [32] = {{"heart_p_bl", "consumable"}, {"heart_p_total", "consumable"}},
    [33] = {{"heart_o_bl", "toggle"}, {"heart_o_total", "consumable"}},
    [34] = {{"heart_p_dc", "consumable"}, {"heart_p_total", "consumable"}},
    [35] = {{"heart_o_dc", "consumable"}, {"heart_o_total", "consumable"}},
    [36] = {{"heart_p_kl", "consumable"}, {"heart_p_total", "consumable"}},
    [37] = {{"heart_o_kl", "consumable"}, {"heart_o_total", "consumable"}},
    [38] = {{"heart_y_kl", "consumable"}, {"heart_y_total", "consumable"}},
    [39] = {{"heart_p_gc", "consumable"}, {"heart_p_total", "consumable"}},
    [40] = {{"heart_o_gc", "consumable"}, {"heart_o_total", "consumable"}},
    [41] = {{"heart_y_gc", "consumable"}, {"heart_y_total", "consumable"}},
    [42] = {{"watch", "consumable"}},
    [43] = {{"big", "consumable"}}, 
    [44] = {{"shrink", "consumable"}},
    [45] = {{"rabbits", "consumable"}},
    [46] = {{"LK", "toggle"}},
    [47] = {{"Qu", "toggle"}},
    [48] = {{"S", "toggle"}},
    [49] = {{"A", "toggle"}},
    [50] = {{"C", "toggle"}},
    [51] = {{"B", "toggle"}},
    [52] = {{"LK7", "toggle"}},
    [53] = {{"QS7", "toggle"}}, 
    [54] = {{"S7", "toggle"}},
    [55] = {{"A7", "toggle"}},
    [56] = {{"C7", "toggle"}},
    [57] = {{"B7", "toggle"}}

}